# NIVEST — projeto inicial multiplataforma

Base de desenvolvimento da NIVEST com React + TypeScript + Vite, Tauri 2 para empacotamento desktop/mobile e Supabase para autenticação e dados online.

## Estado atual

Esta entrega é uma **primeira base de desenvolvimento**, não um produto de produção concluído. Inclui interface inicial navegável, autenticação Supabase preparada, telas iniciais de visão geral/negócios/finanças/Nivy/Premium/equipe, estrutura Tauri e schema SQL inicial com RLS e limite gratuito de 15 negócios.

Ainda precisam ser implementados e configurados antes do lançamento: fluxos completos de planejamento e gestão, catálogo/estoque/clientes/fornecedores, convites e permissões detalhadas, painel administrativo, notificações, exportação PDF/XLSX, integração real da Nivy, provedor de cobrança recorrente, testes abrangentes, política/termos, ícones e builds assinados.

## Requisitos

- Node.js 20 ou superior
- Rust + Cargo
- Dependências nativas Tauri 2 para seu sistema operacional
- Para Android: Android Studio, Android SDK, NDK e JDK compatível
- Para macOS: macOS e Xcode Command Line Tools para compilar/assinar o app Mac
- Projeto Supabase

## Configuração local

1. Instale as dependências:

   ```bash
   npm install
   ```

2. Crie um projeto Supabase e copie `.env.example` para `.env`.
3. Preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`.
4. No SQL Editor do Supabase, execute `supabase/schema.sql`.
5. Em Authentication, configure e-mail, confirmação de conta e o provedor Google (OAuth client e redirect URLs).
6. Inicie a interface de desenvolvimento:

   ```bash
   npm run dev
   ```

7. Para desktop, com Rust e dependências Tauri instaladas:

   ```bash
   npm run tauri dev
   ```

## Builds

- Windows: `npm run tauri build` em Windows, para gerar instalador NSIS/MSI conforme configuração.
- macOS: `npm run tauri build` em macOS, para gerar `.app`/`.dmg`; assinatura e notarização exigem certificados/conta Apple adequados.
- Android: inicialize o alvo Android Tauri 2 com `npx tauri android init`, configure SDK/NDK e compile em ambiente Android.

Os builds nativos não foram gerados neste ambiente porque ele não contém Rust/Cargo, Android SDK/NDK, nem macOS/Xcode.

## Variáveis e segredos

Nunca coloque chaves privadas de IA, service-role keys do Supabase ou credenciais do gateway de pagamento no frontend. A Nivy e o billing devem ser implementados por funções server-side (por exemplo, Supabase Edge Functions) com secrets configurados no servidor.

## Regras de negócio acordadas

- Plano gratuito: até 15 negócios.
- Premium: R$ 19,90/mês, somente mensal, com 14 dias de teste grátis.
- Benefícios Premium: negócios ilimitados, relatórios avançados, Nivy avançada e análises financeiras avançadas.
- As cobranças recorrentes e a concessão de Premium só podem ser confirmadas por webhook autenticado do provedor de pagamentos. O período de teste precisa ser apresentado com transparência e cancelamento disponível.
- Aplicativo online: a experiência exige conexão com a internet.
