-- NIVEST database foundation (Supabase / PostgreSQL)
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  segment text,
  description text,
  logo_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists businesses_owner_id_idx on public.businesses(owner_id);

create table if not exists public.financial_entries (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  business_id uuid references public.businesses(id) on delete set null,
  kind text not null check (kind in ('income','expense')),
  description text not null,
  amount numeric(14,2) not null check (amount > 0),
  category text,
  occurred_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index if not exists financial_entries_owner_id_idx on public.financial_entries(owner_id, created_at desc);

create table if not exists public.business_members (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','partner','admin','employee')),
  permissions jsonb not null default '{}'::jsonb,
  invited_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique (business_id, user_id)
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null,
  provider_customer_id text,
  provider_subscription_id text unique,
  status text not null default 'inactive',
  plan text not null default 'free' check (plan in ('free','premium')),
  trial_ends_at timestamptz,
  current_period_ends_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null,
  message text not null,
  status text not null default 'open' check (status in ('open','in_progress','answered','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.businesses enable row level security;
alter table public.financial_entries enable row level security;
alter table public.business_members enable row level security;
alter table public.subscriptions enable row level security;
alter table public.support_tickets enable row level security;

create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "businesses_select_own" on public.businesses for select using (auth.uid() = owner_id);
create policy "businesses_insert_own" on public.businesses for insert with check (auth.uid() = owner_id);
create policy "businesses_update_own" on public.businesses for update using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "businesses_delete_own" on public.businesses for delete using (auth.uid() = owner_id);
create policy "entries_select_own" on public.financial_entries for select using (auth.uid() = owner_id);
create policy "entries_insert_own" on public.financial_entries for insert with check (auth.uid() = owner_id);
create policy "entries_update_own" on public.financial_entries for update using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "entries_delete_own" on public.financial_entries for delete using (auth.uid() = owner_id);
create policy "members_select_related" on public.business_members for select using (auth.uid() = user_id or exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=auth.uid()));
create policy "members_owner_manage" on public.business_members for all using (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=auth.uid())) with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=auth.uid()));
create policy "subscriptions_select_own" on public.subscriptions for select using (auth.uid() = user_id);
create policy "tickets_select_own" on public.support_tickets for select using (auth.uid() = user_id);
create policy "tickets_insert_own" on public.support_tickets for insert with check (auth.uid() = user_id);

-- Enforce free-plan 15-business cap on the server. Premium entitlement must be
-- verified from a trusted billing webhook before setting plan='premium'.
create or replace function public.enforce_business_limit()
returns trigger language plpgsql security definer set search_path=public as $$
declare current_plan text; business_count integer;
begin
  select coalesce((select plan from public.subscriptions where user_id=new.owner_id and status in ('active','trialing') order by created_at desc limit 1),'free') into current_plan;
  if current_plan <> 'premium' then
    select count(*) into business_count from public.businesses where owner_id=new.owner_id;
    if business_count >= 15 then raise exception 'FREE_PLAN_BUSINESS_LIMIT_REACHED'; end if;
  end if;
  return new;
end; $$;
drop trigger if exists businesses_limit_before_insert on public.businesses;
create trigger businesses_limit_before_insert before insert on public.businesses for each row execute function public.enforce_business_limit();

-- Create a profile row whenever a new auth account is created.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,full_name) values(new.id, new.raw_user_meta_data->>'full_name') on conflict(id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
